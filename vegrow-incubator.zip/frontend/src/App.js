import React from "react";
import { ethers } from "ethers";

// Replace with deployed addresses
const INC_ADDRESS = process.env.REACT_APP_INC_ADDRESS || "0x...";
const B3TR_ADDRESS = process.env.REACT_APP_B3TR_ADDRESS || "0x...";

const abiInc = [
  "function registerProject(string calldata metadataURI, bool approved) external returns (uint256)",
  "function addMilestone(uint256,string calldata,uint256,uint256) external",
  "function contributeToProject(uint256) external payable"
];

const abiERC20 = [
  "function approve(address,uint256) external returns (bool)",
  "function allowance(address,address) view returns (uint256)",
  "function balanceOf(address) view returns (uint256)"
];

function App() {
  const connect = async () => {
    if (!window.ethereum) {
      alert('VeWorld or EIP-1193 wallet not found');
      return;
    }
    await window.ethereum.request({ method: "eth_requestAccounts" });
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    console.log("Connected", address);
    return { provider, signer };
  };

  const registerProject = async () => {
    const { signer } = await connect();
    const inc = new ethers.Contract(INC_ADDRESS, abiInc, signer);
    const tx = await inc.registerProject("ipfs://Qm.../metadata.json", true);
    await tx.wait();
    alert("Project registered");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>VeGrow — Minimal Frontend</h1>
      <button onClick={registerProject}>Connect & Register Demo Project</button>
    </div>
  );
}

export default App;
