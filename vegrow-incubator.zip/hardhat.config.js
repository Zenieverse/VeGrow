import "@nomiclabs/hardhat-ethers";
import "dotenv/config";

module.exports = {
  solidity: "0.8.20",
  networks: {
    vechain: {
      url: process.env.VETHOR_RPC || "https://vechain-thor-rpc.example",
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
      chainId: process.env.VECHAIN_CHAIN_ID ? Number(process.env.VECHAIN_CHAIN_ID) : 74
    }
  }
};
