# VeGrow Incubator — Repository (MVP)

This repository contains a minimal prototype of **VeGrow** — a decentralized incubator & reward hub for VeChain (VeChainThor), using **B3TR** as the reward token.

## Contents
- `contracts/VeGrowIncubator.sol` — main Solidity contract (prototype)
- `contracts/IERC20.sol` — minimal ERC20 interface
- `scripts/deploy.js` — simple Hardhat deployment script
- `hardhat.config.js` — sample Hardhat config
- `frontend/` — minimal frontend scaffold with connection snippets
- `video_script.txt`, `pitch_deck.md`, `app_canvas_prompt.txt` — supporting materials

## Quickstart (local / test)
1. Install dependencies:
   ```bash
   npm install
   ```

2. Create a `.env` file with:
   ```
   VETHOR_RPC=https://<vechain-rpc-endpoint>
   PRIVATE_KEY=0x...
   B3TR_ADDRESS=0x...   # B3TR token contract address on the target network
   VECHAIN_CHAIN_ID=74  # replace with actual chain id if different
   ```

3. Compile contracts:
   ```bash
   npx hardhat compile
   ```

4. Deploy to VeChainThor (testnet/mainnet):
   ```bash
   node scripts/deploy.js
   ```

> Note: This is an MVP prototype. For production, use multisig for owner, robust voting with one-vote-per-contributor accounting, and audit the contract.

## Frontend
A minimal React frontend scaffold is provided under `frontend/`. It demonstrates:
- VeWorld / EIP-1193 wallet connect
- Approve B3TR -> add milestone -> contribute -> vote -> finalize flows (snippets only)

## Files of interest
- `video_script.txt` — narration for a 4–5 minute demo video
- `pitch_deck.md` — slide-by-slide pitch deck content
- `app_canvas_prompt.txt` — detailed prompt for an app-builder tool to generate the full frontend

## License
MIT
