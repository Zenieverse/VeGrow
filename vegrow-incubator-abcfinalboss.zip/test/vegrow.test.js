// Hardhat tests for VeGrowIncubator
const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('VeGrowIncubator', function () {
  let owner, alice, bob, Incubator, incubator, Token, token;

  beforeEach(async function () {
    [owner, alice, bob] = await ethers.getSigners();
    Token = await ethers.getContractFactory('MockERC20');
    token = await Token.deploy('B3TR Mock', 'B3TR', ethers.parseUnits('1000000', 18));
    await token.deployed();

    Incubator = await ethers.getContractFactory('VeGrowIncubator');
    incubator = await Incubator.deploy(token.target, 0);
    await incubator.deployed();
  });

  it('registers project and allows contributions', async function () {
    await incubator.connect(alice).registerProject('ipfs://meta', true);
    await incubator.connect(bob).contributeToProject(1, { value: ethers.parseEther('0.1') });
    const s = await incubator.getProjectSummary(1);
    expect(s[2]).to.equal(ethers.parseEther('0.1'));
  });

  it('voting finalization and claimReward flow', async function () {
    await incubator.connect(alice).registerProject('ipfs://meta', true);
    // alice provides B3TR and creates milestone
    await token.transfer(alice.address, ethers.parseUnits('1000',18));
    await token.connect(alice).approve(incubator.target, ethers.parseUnits('200',18));
    await incubator.connect(alice).addMilestone(1, 'demo', ethers.parseUnits('200',18), 0);
    // bob contributes and receives some B3TR to meet gating
    await token.transfer(bob.address, ethers.parseUnits('10',18));
    await incubator.connect(bob).contributeToProject(1, { value: ethers.parseEther('0.2') });
    await incubator.connect(bob).voteMilestone(1, 0, true);
    await incubator.connect(alice).finalizeMilestone(1, 0);
    const before = await token.balanceOf(alice.address);
    await incubator.connect(alice).claimReward(1,0);
    const after = await token.balanceOf(alice.address);
    expect(after).to.be.gt(before);
  });

  it('schedules and executes rescue after timelock', async function () {
    // send 500 tokens to contract
    await token.transfer(incubator.target, ethers.parseUnits('500',18));
    const contractBal = await token.balanceOf(incubator.target);
    expect(contractBal).to.equal(ethers.parseUnits('500',18));
    // schedule rescue to bob
    await incubator.connect(owner).scheduleRescue(bob.address, ethers.parseUnits('200',18));
    // execute early should revert
    await expect(incubator.connect(owner).executeRescue()).to.be.revertedWith('too early');
    // advance time
    const tl = await incubator.rescueTimelockSeconds();
    await ethers.provider.send('evm_increaseTime', [Number(tl)+1]);
    await ethers.provider.send('evm_mine', []);
    // execute
    await incubator.connect(owner).executeRescue();
    const bobBal = await token.balanceOf(bob.address);
    expect(bobBal).to.equal(ethers.parseUnits('200',18));
  });
});
