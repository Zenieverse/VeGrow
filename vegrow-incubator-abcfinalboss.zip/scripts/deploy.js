const hre = require('hardhat');
async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying from', deployer.address);
  const B3TR_ADDRESS = process.env.B3TR_ADDRESS || '0x0000000000000000000000000000000000000000';
  const Inc = await hre.ethers.getContractFactory('VeGrowIncubator');
  const inc = await Inc.deploy(B3TR_ADDRESS, 0);
  await inc.deployed();
  console.log('VeGrowIncubator deployed to:', inc.target || inc.address);
}
main().catch(err => { console.error(err); process.exit(1); });
