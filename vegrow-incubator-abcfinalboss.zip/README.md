VeGrow Incubator — Final MVP (abcfinalboss)
This package contains a full-stack MVP:
- Solidity contract with claimReward, timelocked rescue, and min B3TR voting gating.
- Hardhat tests that cover claim and rescue flows.
- React frontend with claim & admin rescue UI.
- GitHub Actions deploy workflow that deploys on tagged releases.

Run locally:
1. npm install
2. npx hardhat compile
3. npx hardhat test
4. cd frontend && npm install && npm start

DO NOT PROVIDE PRIVATE KEYS HERE. Use .env and GitHub secrets for deploy.
