require('dotenv').config();
require('@nomiclabs/hardhat-ethers');
module.exports = {
  solidity: '0.8.20',
  networks: {
    hardhat: {},
    vechain: {
      url: process.env.VETHOR_RPC || '',
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
      chainId: process.env.VECHAIN_CHAIN_ID ? Number(process.env.VECHAIN_CHAIN_ID) : 74
    }
  }
};
