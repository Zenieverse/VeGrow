import React, { useState } from 'react';
export default function ProjectForm({ onSubmit }) {
  const [ipfs, setIpfs] = useState('');
  const submit = (e) => {
    e.preventDefault();
    if (!ipfs) return alert('IPFS required');
    onSubmit({ metadataURI: ipfs });
  };
  return (
    <form onSubmit={submit}>
      <input placeholder="ipfs://..." value={ipfs} onChange={e=>setIpfs(e.target.value)} />
      <button type="submit">Register</button>
    </form>
  );
}
