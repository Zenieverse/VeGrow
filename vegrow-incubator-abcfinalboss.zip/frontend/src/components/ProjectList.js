import React from 'react';
export default function ProjectList({ projects, onSelect }) {
  if (!projects || projects.length === 0) return <div>No projects</div>;
  return <div>{projects.map(p=> <div key={p.id}><strong>{p.metadataURI}</strong> <button onClick={()=>onSelect(p.id)}>Open</button></div>)}</div>;
}
