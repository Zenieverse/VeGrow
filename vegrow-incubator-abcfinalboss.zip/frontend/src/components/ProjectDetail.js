import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';
const abiInc = [
  'function getProjectSummary(uint256) view returns (address,string,uint256,bool,bool,uint256,uint256,uint256)',
  'function getMilestone(uint256,uint256) view returns (string,uint256,bool,uint256,uint256,uint256,bool,bool)',
  'function contributeToProject(uint256) external payable',
  'function claimReward(uint256,uint256) external',
  'function scheduleRescue(address,uint256) external',
  'function executeRescue() external',
  'function owner() view returns (address)'
];
export default function ProjectDetail({ provider, signer, projectId, incAddress }) {
  const [summary, setSummary] = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [status, setStatus] = useState('');
  const [adminTo, setAdminTo] = useState('');
  const [adminAmount, setAdminAmount] = useState('');
  const inc = incAddress && provider ? new ethers.Contract(incAddress, abiInc, provider) : null;
  useEffect(()=>{ if (!inc || !projectId) return; (async ()=>{ const s = await inc.getProjectSummary(projectId); setSummary(s); const count = Number(s[7]); const ms=[]; for (let i=0;i<count;i++){ const m = await inc.getMilestone(projectId,i); ms.push({ index:i, description:m[0], reward:m[1].toString(), completed:m[2], rewardClaimed:m[6], accepted:m[7] }); } setMilestones(ms); })(); },[inc,projectId]);
  const contribute = async ()=>{ if(!signer) return alert('connect'); const incS = new ethers.Contract(incAddress, abiInc, signer); const tx = await incS.contributeToProject(projectId, { value: ethers.parseEther('0.01') }); await tx.wait(); setStatus('contributed'); };
  const claim = async (idx)=>{ if(!signer) return alert('connect'); try{ setStatus('claiming'); const incS = new ethers.Contract(incAddress, abiInc, signer); const tx = await incS.claimReward(projectId, idx); await tx.wait(); setStatus('claimed'); }catch(e){ setStatus('claim failed: '+e.message); } };
  const schedule = async ()=>{ if(!signer) return alert('connect'); try{ const incS = new ethers.Contract(incAddress, abiInc, signer); const amt = ethers.parseUnits(adminAmount||'0',18); const tx = await incS.scheduleRescue(adminTo, amt); await tx.wait(); setStatus('rescue scheduled'); }catch(e){ setStatus('schedule failed: '+e.message); } };
  const execute = async ()=>{ if(!signer) return alert('connect'); try{ const incS = new ethers.Contract(incAddress, abiInc, signer); const tx = await incS.executeRescue(); await tx.wait(); setStatus('rescue executed'); }catch(e){ setStatus('execute failed: '+e.message); } };
  return (<div><h3>Project {projectId}</h3>{summary && <div><div>Creator: {summary[0]}</div><div>Metadata: {summary[1]}</div></div>}<button onClick={contribute}>Contribute 0.01 VET</button><h4>Milestones</h4>{milestones.map(m=>(<div key={m.index}><div>{m.description}</div><div>Reward: {m.reward}</div><div>Accepted: {m.accepted?'yes':'no'}</div><div>Claimed: {m.rewardClaimed?'yes':'no'}</div>{m.accepted && !m.rewardClaimed && <button onClick={()=>claim(m.index)}>Claim Reward</button>}</div>))}<div>Status: {status}</div><hr/><div><h4>Admin Rescue (owner)</h4><input placeholder="to address" value={adminTo} onChange={e=>setAdminTo(e.target.value)}/><input placeholder="amount" value={adminAmount} onChange={e=>setAdminAmount(e.target.value)}/><button onClick={schedule}>Schedule Rescue</button><button onClick={execute}>Execute Rescue</button></div></div>); 
}
