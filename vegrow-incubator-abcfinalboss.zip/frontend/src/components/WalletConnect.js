import React, { useState } from 'react';
import { ethers } from 'ethers';
export default function WalletConnect({ onConnect }) {
  const [addr, setAddr] = useState('');
  const connect = async () => {
    if (!window.ethereum) return alert('No EIP-1193 wallet found');
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    setAddr(address);
    onConnect({ provider, signer, address });
  };
  return <button onClick={connect}>{addr ? 'Connected: ' + addr : 'Connect Wallet'}</button>;
}
