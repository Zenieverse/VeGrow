# VeGrow Incubator — Full MVP Package

This expanded repository contains:
- Solidity contracts (incubator prototype + mock ERC20 for tests)
- Full Hardhat test suite
- Frontend scaffold (create-react-app style) with VeWorld / EIP-1193 wallet connect snippets
- PPTX pitch deck (if generated) or markdown fallback
- Scripts and instructions to compile, test, and run locally

## Quickstart

1. Install root deps:
   ```
   npm install
   ```

2. Install frontend deps:
   ```
   cd frontend
   npm install
   ```

3. Compile contracts:
   ```
   npx hardhat compile
   ```

4. Run tests:
   ```
   npx hardhat test
   ```

5. Run frontend:
   ```
   cd frontend
   npm start
   ```

## Notes on deploying to VeChain
- You will need a VeChainThor RPC endpoint and private key. Add them to `.env`:
  ```
  VETHOR_RPC=https://<vechain-rpc>
  PRIVATE_KEY=0x...
  B3TR_ADDRESS=0x...
  VECHAIN_CHAIN_ID=74
  ```
- Then deploy:
  ```
  node scripts/deploy.js
  ```

## Security
- This is an MVP. Use multisig for owner keys and audit before production.



## Additional files
- `.github/workflows/ci.yml` — CI pipeline for compile, test, and frontend build
- `SECURITY_CHECKLIST.md` — recommended security hardening
- `MIGRATION.md` — deployment steps and multisig guidance
