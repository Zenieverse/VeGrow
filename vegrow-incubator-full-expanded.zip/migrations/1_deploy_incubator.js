// Migration script example for deployments (use with truffle or adapt for your pipeline)
// This is a template — adapt to your deployment tooling.
const VeGrowIncubator = artifacts.require("VeGrowIncubator");

module.exports = async function(deployer, network, accounts) {
  const b3tr = process.env.B3TR_ADDRESS || "0x0000000000000000000000000000000000000000";
  await deployer.deploy(VeGrowIncubator, b3tr);
  const instance = await VeGrowIncubator.deployed();
  console.log("Deployed VeGrowIncubator at", instance.address);
};
