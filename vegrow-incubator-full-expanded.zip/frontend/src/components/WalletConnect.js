import React, { useState } from 'react';
import { ethers } from 'ethers';

export default function WalletConnect({ onConnect }) {
  const [address, setAddress] = useState(null);
  const connect = async () => {
    if (!window.ethereum) {
      alert('VeWorld or EIP-1193 wallet not found');
      return;
    }
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const addr = await signer.getAddress();
    setAddress(addr);
    onConnect({ provider, signer, address: addr });
  };
  return (
    <div>
      <button onClick={connect}>{address ? 'Connected: ' + address : 'Connect Wallet (VeWorld)'}</button>
    </div>
  );
}
