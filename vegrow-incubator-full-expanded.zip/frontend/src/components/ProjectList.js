import React from 'react';

export default function ProjectList({ projects, onSelect }) {
  if (!projects || projects.length === 0) return <div>No projects yet</div>;
  return (
    <div>
      {projects.map(p => (
        <div key={p.id} style={{ border: '1px solid #ddd', padding: 8, marginBottom: 8 }}>
          <strong>{p.metadataURI}</strong>
          <div>Creator: {p.creator}</div>
          <div>Funding: {p.fundingReceived} wei</div>
          <button onClick={() => onSelect(p.id)}>View</button>
        </div>
      ))}
    </div>
  );
}
