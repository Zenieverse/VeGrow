import React, { useState } from 'react';

export default function ProjectForm({ onSubmit }) {
  const [title, setTitle] = useState('');
  const [ipfs, setIpfs] = useState('');
  const submit = (e) => {
    e.preventDefault();
    if (!title || !ipfs) return alert('fill title and ipfs url');
    onSubmit({ metadataURI: ipfs, title });
  };
  return (
    <form onSubmit={submit}>
      <div>
        <label>Title</label><br/>
        <input value={title} onChange={e=>setTitle(e.target.value)} />
      </div>
      <div>
        <label>IPFS Metadata URL</label><br/>
        <input value={ipfs} onChange={e=>setIpfs(e.target.value)} />
      </div>
      <button type="submit">Register Project</button>
    </form>
  );
}
