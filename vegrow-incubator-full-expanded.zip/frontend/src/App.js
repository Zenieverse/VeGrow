import React, { useState } from 'react';
import WalletConnect from './components/WalletConnect';
import ProjectForm from './components/ProjectForm';
import ProjectList from './components/ProjectList';
import { ethers } from 'ethers';

const INC_ADDRESS = process.env.REACT_APP_INC_ADDRESS || '';
const B3TR_ADDRESS = process.env.REACT_APP_B3TR_ADDRESS || '';

const abiInc = [
  'function registerProject(string calldata metadataURI, bool approved) external returns (uint256)',
  'function getProjectSummary(uint256) view returns (address,string,uint256,bool,bool,uint256,uint256,uint256)',
  'function projectCount() view returns (uint256)'
];

export default function App() {
  const [ctx, setCtx] = useState(null);
  const [projects, setProjects] = useState([]);

  const onConnect = ({ provider, signer, address }) => {
    setCtx({ provider, signer, address });
    loadProjects(provider);
  };

  const loadProjects = async (provider) => {
    if (!INC_ADDRESS) return;
    const inc = new ethers.Contract(INC_ADDRESS, abiInc, provider);
    const count = await inc.projectCount();
    const arr = [];
    for (let i = 1; i <= Number(count); i++) {
      try {
        const res = await inc.getProjectSummary(i);
        arr.push({ id: i, creator: res[0], metadataURI: res[1], fundingReceived: res[2].toString(), active: res[3] });
      } catch (e) {
        console.error('load project', i, e);
      }
    }
    setProjects(arr);
  };

  const registerProject = async ({ metadataURI }) => {
    if (!ctx) return alert('connect wallet first');
    const inc = new ethers.Contract(INC_ADDRESS, abiInc, ctx.signer);
    const tx = await inc.registerProject(metadataURI, true);
    await tx.wait();
    alert('registered');
    loadProjects(ctx.provider);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>VeGrow — Incubator</h1>
      <WalletConnect onConnect={onConnect} />
      <hr />
      <h2>Register Project</h2>
      <ProjectForm onSubmit={registerProject} />
      <hr />
      <h2>Projects</h2>
      <ProjectList projects={projects} onSelect={(id)=>alert('open project '+id)} />
    </div>
  );
}
