# Security & Audit Checklist — VeGrow Incubator

This document lists recommended security measures before production deployment.

1. **Smart contract audit**
   - Third-party audit (recommended).
   - Static analysis (Slither / MythX).
   - Gas usage and edge-case checks.

2. **Replace owner with multisig**
   - Use Gnosis Safe or VeChain multisig for admin functions (rescueB3TR).
   - Remove or limit `rescueB3TR` capability or gate it to timelock + multisig.

3. **Voting & replay protections**
   - Implement per-voter one-vote tracking to prevent double-voting.
   - Consider snapshot-based voting weights.

4. **Escrow & token handling**
   - Check ERC20 `transferFrom` assumptions (handle tokens that don't return bool).
   - Implement pull-over-push pattern for reward claiming if needed.

5. **Reentrancy & access control**
   - Use OpenZeppelin `ReentrancyGuard` and `Ownable` patterns.

6. **Input validation**
   - Validate IPFS URIs and metadata formats server-side.
   - Limit maximum sizes if storing on-chain (we store only pointers).

7. **Off-chain AI scoring**
   - Treat AI scores as advisory metadata; do not let them directly trigger transfers.
   - Authenticate AI scoring endpoints and use signed attestations if asserting scores on-chain.

8. **Operational procedures**
   - Keep private keys offline; rotate keys on a schedule.
   - Monitor contracts with alerts for large transfers.

