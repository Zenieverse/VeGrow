# Deployment & Migration Guide

1. Prepare environment variables in `.env`:
   ```
   VETHOR_RPC=https://<vechain-rpc>
   PRIVATE_KEY=0x...
   B3TR_ADDRESS=0x...
   VECHAIN_CHAIN_ID=74
   ```

2. Compile contracts:
   ```
   npx hardhat compile
   ```

3. Deploy:
   ```
   node scripts/deploy.js
   ```

4. Verify:
   - Use VeChain explorer to search deployed contract address.
   - Set addresses in frontend `.env`:
     REACT_APP_INC_ADDRESS=<deployed address>
     REACT_APP_B3TR_ADDRESS=<b3tr address>
   - Restart frontend (`npm start`).

5. For multisig:
   - Deploy contract with your deployer account.
   - Transfer ownership to your multisig immediately after deployment.

