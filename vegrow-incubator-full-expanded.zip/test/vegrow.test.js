const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('VeGrowIncubator', function () {
  let Incubator, incubator, Token, token, owner, alice, bob;

  beforeEach(async function () {
    [owner, alice, bob] = await ethers.getSigners();

    // Deploy a mock ERC20 for B3TR
    Token = await ethers.getContractFactory('MockERC20');
    token = await Token.deploy('B3TR Mock', 'B3TR', ethers.parseUnits('1000000', 18));
    await token.deployed();

    Incubator = await ethers.getContractFactory('VeGrowIncubator');
    incubator = await Incubator.deploy(token.target);
    await incubator.deployed();
  });

  it('registers project and allows contributions', async function () {
    const tx = await incubator.connect(alice).registerProject('ipfs://testmeta', true);
    await tx.wait();
    const pid = 1;
    await incubator.connect(bob).contributeToProject(pid, { value: ethers.parseEther('0.1') });
    const summary = await incubator.getProjectSummary(pid);
    expect(summary.fundingReceived).to.equal(ethers.parseEther('0.1'));
  });

  it('allows adding milestone with B3TR escrow and finalization', async function () {
    await incubator.connect(alice).registerProject('ipfs://testmeta', true);
    const pid = 1;
    // transfer some token to alice and approve
    await token.transfer(alice.address, ethers.parseUnits('1000', 18));
    await token.connect(alice).approve(incubator.target, ethers.parseUnits('200', 18));
    await incubator.connect(alice).addMilestone(pid, 'demo', ethers.parseUnits('200', 18), 0);
    // contributor funds and votes
    await incubator.connect(bob).contributeToProject(pid, { value: ethers.parseEther('0.2') });
    await incubator.connect(bob).voteMilestone(pid, 0, true);
    // finalize
    await incubator.connect(alice).finalizeMilestone(pid, 0);
    const summary = await incubator.getProjectSummary(pid);
    expect(summary.totalB3TRBudget).to.equal(ethers.parseUnits('0', 18));
  });
});
